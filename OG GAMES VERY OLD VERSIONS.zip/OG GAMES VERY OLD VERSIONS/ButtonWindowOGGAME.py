import tkinter as tk

def display_text_one():
    label.config(text="Button 1 clicked!")

def display_text_two():
    label.config(text="Button 2 clicked!")

root = tk.Tk()

root.title("Button Text Display")

root.geometry("400x300")  # Width x Height

label = tk.Label(root, text="Click a button", font=("Arial", 24))
label.pack(pady=20)

button1 = tk.Button(root, text="Button 1", command=display_text_one)
button1.pack(pady=10)

button2 = tk.Button(root, text="Button 2", command=display_text_two)
button2.pack(pady=10)

root.mainloop()
