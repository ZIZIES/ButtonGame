import tkinter as tk

root = tk.Tk()

root.title("Blank Window")

root.geometry("700x450")

root.mainloop()
